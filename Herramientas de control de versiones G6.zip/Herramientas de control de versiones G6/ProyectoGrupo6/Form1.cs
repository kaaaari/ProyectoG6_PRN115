﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoGrupo6
{
    public partial class ProyectoGrupo6 : Form
    {
        public ProyectoGrupo6()
        {
            InitializeComponent();
        }

        private void lblDescuentos_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click_1(object sender, EventArgs e)
        {
         
            if (string.IsNullOrWhiteSpace(txtNombre.Text) ||
                string.IsNullOrWhiteSpace(txtApellidos.Text) ||
                string.IsNullOrWhiteSpace(txtPrecioProducto.Text) ||
                cmbNombreProducto.SelectedIndex == -1 ||
                (!rbEfectivo.Checked && !rbTarjeta.Checked))
            {
                MessageBox.Show("Por favor completa todos los campos.");
                return;
            }

            try
            {

                string nombreProducto = cmbNombreProducto.SelectedItem.ToString();
                decimal precioProducto = decimal.Parse(txtPrecioProducto.Text);
                int cantidadProducto = (int)numCantidadProducto.Value;
                ///int cantidadProducto = int.Parse(txtCantidadProducto.Text);

                decimal totalProducto = precioProducto * cantidadProducto;

                decimal descuento = 0;
                if (totalProducto > 100)
                {
                    descuento = totalProducto * 0.10m; 
                }
                else if (totalProducto > 50)
                {
                    descuento = totalProducto * 0.05m; 
                }

                if (rbTarjeta.Checked)
                {
                    
                     decimal comisionTarjeta = totalProducto * 0.03m;     
                     totalProducto += comisionTarjeta;
                    
                }


                decimal totalFinal = totalProducto - descuento;

                
                lblDescuento.Text = $"Descuento aplicado: ${descuento:F2}";

                
                lblTotal.Text = $"Total a pagar: ${totalFinal:F2}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al calcular: {ex.Message}");
            }
        }

        private void btnLimpiar_Click_1(object sender, EventArgs e)
        {
            txtNombre.Clear();
            txtApellidos.Clear();
            cmbNombreProducto.SelectedIndex = -1;
            txtPrecioProducto.Clear();
            numCantidadProducto.Value = 0;
            rbEfectivo.Checked = false;
            rbTarjeta.Checked = false;


            lblDescuento.Text = "Descuento aplicado: $0.00";
            lblTotal.Text = "Total a pagar: $0.00";
        }

        private void btnSalir_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
